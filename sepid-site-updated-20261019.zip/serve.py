"""Run the static Sepid site with byte-range support for the implant film.

    python serve.py [port]

Production static hosts (Netlify, Vercel, nginx, Apache, etc.) already support
HTTP Range. Python's stock SimpleHTTPRequestHandler does not, so this tiny
server adds it for local playback and reversible chapter seeking.
"""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import os
import re
import sys


class RangeHandler(SimpleHTTPRequestHandler):
    def send_head(self):
        # For GET /, the base class opens index.html and calls our copyfile().
        # Initialize the range state before that directory branch too.
        self.range_left = None
        path = self.translate_path(self.path)
        if os.path.isdir(path):
            return super().send_head()
        try:
            file = open(path, 'rb')
        except OSError:
            self.send_error(404, 'File not found')
            return None
        size = os.fstat(file.fileno()).st_size
        match = re.fullmatch(r'bytes=(\d+)-(\d*)', self.headers.get('Range', ''))
        if match:
            start = int(match.group(1))
            end = min(size - 1, int(match.group(2))) if match.group(2) else size - 1
            if start >= size or end < start:
                self.send_response(416)
                self.send_header('Content-Range', f'bytes */{size}')
                self.end_headers()
                file.close()
                return None
            self.range_left = end - start + 1
            file.seek(start)
            self.send_response(206)
            self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
            self.send_header('Content-Length', str(self.range_left))
        else:
            self.range_left = None
            self.send_response(200)
            self.send_header('Content-Length', str(size))
        self.send_header('Content-Type', self.guess_type(path))
        self.send_header('Accept-Ranges', 'bytes')
        self.end_headers()
        return file

    def copyfile(self, source, outputfile):
        remaining = self.range_left
        if remaining is None:
            return super().copyfile(source, outputfile)
        while remaining:
            block = source.read(min(64 * 1024, remaining))
            if not block:
                break
            outputfile.write(block)
            remaining -= len(block)


port = int(sys.argv[1]) if len(sys.argv) > 1 else 3000
root = Path(__file__).resolve().parent
handler = partial(RangeHandler, directory=str(root))
print(f'Sepid: http://localhost:{port}/index.html', flush=True)
try:
    ThreadingHTTPServer(('0.0.0.0', port), handler).serve_forever()
except KeyboardInterrupt:
    print('\nStopped.')
