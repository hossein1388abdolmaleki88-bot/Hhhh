/* Sepid — three-step, full-screen implant film.
   One scroll gesture = exactly one move, whether it is a tiny flick, a long fast spin or a trackpad glide.
   Moves ease in/out; quick repeated gestures are queued and each accepted input triggers a brief spark burst. */
const film = document.querySelector('[data-implant-film]');

if (film) {
  const root = document.documentElement;
  const video = film.querySelector('[data-film-video]');
  const reverseVideo = film.querySelector('[data-film-reverse]');
  const sparkLayer = film.querySelector('[data-film-sparkles]');
  const heading = film.querySelector('#implant-story-title');
  const status = film.querySelector('[data-film-status]');
  const help = film.querySelector('[data-film-help]');
  const cue = film.querySelector('[data-film-cue]');
  const cueText = film.querySelector('[data-film-cue-text]');
  const progress = film.querySelector('[data-film-progress]');
  const progressSegments = [...film.querySelectorAll('[data-progress-segment]')];
  const markers = [...film.querySelectorAll('[data-stage-marker]')];
  const watermark = film.querySelector('[data-film-watermark]');
  const indexLabel = film.querySelector('[data-film-index]');
  const chapterTitle = film.querySelector('[data-film-chapter-title]');
  const chapterCopy = film.querySelector('[data-film-chapter-copy]');
  const chapterCard = film.querySelector('[data-film-chapter-card]');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const MIN_PIN_HEIGHT = 620;
  const WHEEL_IDLE_MS = 150;       // silence that ends a wheel / trackpad gesture
  const WHEEL_MIN_TOTAL = 2;       // px needed before a gesture counts (filters jitter, still accepts tiny flicks)
  const WHEEL_IMPULSE_MIN = 48;    // larger wheel notches are separate quick gestures, even with no idle gap
  const TOUCH_MIN_TRAVEL = 6;      // px a swipe must travel to count
  const PLAY_SPEED = 2.25;         // slightly quicker; queued scroll moves still play in order
  const RATE_MIN = .85;            // playback rate at the very start / end of a move
  const RAMP_IN = .3;              // seconds of video over which a move eases in
  const RAMP_OUT = .45;            // seconds of video over which a move eases out
  const REENTER_COOLDOWN = 900;    // ms during which the lock cannot re-engage after leaving upward
  const LAST_FRAME_PAD = 1 / 24;
  const chapters = [
    { end: 3.1, title: 'بازشدن ایمپلنت', copy: 'ایمپلنت از حالت یکپارچه باز می‌شود و اجزایش جدا نمایان می‌شوند.' },
    { end: 5.55, title: 'ورود پیچ به فک', copy: 'پایهٔ تیتانیومی در جایگاه خود داخل فک قرار می‌گیرد.' },
    { end: 9.5, title: 'قرارگیری تاج', copy: 'تاج دندان پایین می‌آید و روی پایه در جای خود می‌نشیند.' }
  ];

  const clamp = (value, min = 0, max = 1) => Math.min(max, Math.max(min, value));
  const toFa = value => String(value).replace(/[0-9]/g, digit => '۰۱۲۳۴۵۶۷۸۹'[Number(digit)]);
  const pad2 = value => String(value).padStart(2, '0');
  const canPlayMP4 = Boolean(video && typeof video.canPlayType === 'function' && video.canPlayType('video/mp4'));
  const tallEnough = () => window.innerHeight >= MIN_PIN_HEIGHT;
  const canPin = () => Boolean(canPlayMP4 && !reducedMotion.matches && tallEnough() && !mediaFailed && !video.error);

  // Completion is intentionally per page load: refreshing makes the story playable again.
  let completed = false;
  let mediaFailed = false;
  let active = false;
  let entering = false;
  let entryRaf = 0;
  let entryToken = 0;
  let replaying = false;
  let completedStages = 0;
  let requestedStages = 0;
  let segmentTarget = 0;
  let segmentPlaying = false;
  let segmentDirection = 1;
  let segmentToken = 0;
  let monitorRaf = 0;
  let lockTop = 0;
  let lastScrollY = window.scrollY;
  let userIntentUntil = 0;
  let pendingNavigation = null;
  let reenterBlockedUntil = 0;
  const wheelState = { last: -Infinity, dir: 0, mags: [], count: 0, peak: 0, valley: Infinity, decaying: false, total: 0, consumed: false };
  let touchInProgress = false;
  let skipTouchAdvance = false;
  let touchMoved = false;
  let touchStartY = null;
  let touchLastY = null;
  let lastTouchEndAt = -Infinity;
  let sparkSerial = 0;
  let initDone = false;

  function getDuration() {
    return Number.isFinite(video.duration) && video.duration > 0 ? video.duration : 0;
  }
  function lastFrameTime() {
    const duration = getDuration();
    return duration ? Math.max(0, duration - LAST_FRAME_PAD) : chapters[chapters.length - 1].end;
  }
  function chapterEnd(stage) {
    return stage >= chapters.length ? lastFrameTime() : chapters[stage - 1].end;
  }
  function reverseFrameOffset() {
    const duration = Number.isFinite(reverseVideo.duration) && reverseVideo.duration > 0 ? reverseVideo.duration : getDuration();
    return Math.max(0, duration - LAST_FRAME_PAD);
  }
  function reverseTimeFor(storyTime) {
    return clamp(reverseFrameOffset() - storyTime, 0, reverseFrameOffset());
  }
  function documentTop() { return film.getBoundingClientRect().top + window.scrollY; }
  function servicesEntryOffset() {
    const services = document.getElementById('services');
    if (!services) return 0;
    const header = document.querySelector('.header');
    const headerHeight = header ? header.getBoundingClientRect().height : 0;
    const sectionPadding = parseFloat(getComputedStyle(services).paddingTop) || 0;
    return Math.max(0, headerHeight + 10 - sectionPadding);
  }
  function setStatus(message) { if (status) status.textContent = message; }
  function setHelp(message) { if (help) help.textContent = message; }

  function fireSparkBurst() {
    if (!sparkLayer || reducedMotion.matches) return;
    const stageRect = film.getBoundingClientRect();
    const videoBox = film.querySelector('.implant-film__video-box');
    const boxRect = videoBox ? videoBox.getBoundingClientRect() : null;
    const x = boxRect && boxRect.width ? boxRect.left + boxRect.width * .52 - stageRect.left : stageRect.width * .36;
    const y = boxRect && boxRect.height ? boxRect.top + boxRect.height * .47 - stageRect.top : stageRect.height * .5;
    const burst = document.createElement('span');
    burst.className = 'implant-film__spark-burst';
    burst.dataset.sparkBurst = String(++sparkSerial);
    burst.style.setProperty('--spark-x', `${x}px`);
    burst.style.setProperty('--spark-y', `${y}px`);

    const core = document.createElement('span');
    core.className = 'implant-film__spark-core';
    burst.append(core);
    const count = 14;
    for (let index = 0; index < count; index += 1) {
      const particle = document.createElement('i');
      particle.className = index % 4 === 0 ? 'implant-film__spark implant-film__spark--star' : 'implant-film__spark';
      particle.style.setProperty('--spark-angle', `${index * (360 / count) + (Math.random() * 14 - 7)}deg`);
      particle.style.setProperty('--spark-distance', `${-(32 + Math.random() * 34)}px`);
      particle.style.setProperty('--spark-delay', `${Math.random() * 32}ms`);
      burst.append(particle);
    }
    sparkLayer.append(burst);
    window.setTimeout(() => burst.remove(), 1050);
  }

  function currentDisplayStage() {
    if (segmentTarget) return segmentTarget;
    if (completedStages > 0) return completedStages;
    return 1;
  }

  function refreshUI({ animate = false } = {}) {
    const displayStage = currentDisplayStage();
    const chapter = chapters[displayStage - 1];
    const activeValue = segmentPlaying ? segmentTarget : completedStages;
    const queuedMoves = !segmentPlaying ? 0 : segmentDirection > 0
      ? Math.max(0, requestedStages - segmentTarget)
      : Math.max(0, segmentTarget - requestedStages);
    const shownProgress = Math.max(completedStages, segmentPlaying ? segmentTarget : 0);

    if (watermark) watermark.textContent = toFa(pad2(displayStage));
    if (indexLabel) indexLabel.innerHTML = `حرکت ${toFa(pad2(displayStage))} <b>/</b> ${toFa(pad2(chapters.length))}`;
    if (chapterTitle && chapter) chapterTitle.textContent = chapter.title;
    if (chapterCopy && chapter) chapterCopy.textContent = chapter.copy;

    markers.forEach((marker, index) => {
      const number = index + 1;
      marker.classList.toggle('is-complete', number <= completedStages);
      marker.classList.toggle('is-current', number === displayStage);
      marker.classList.toggle('is-queued', number > completedStages && number <= requestedStages && number !== segmentTarget);
      if (number === displayStage) marker.setAttribute('aria-current', 'step');
      else marker.removeAttribute('aria-current');
    });
    progressSegments.forEach((segment, index) => {
      const number = index + 1;
      segment.classList.toggle('is-complete', number <= completedStages);
      segment.classList.toggle('is-current', segmentPlaying && number === segmentTarget);
      segment.classList.toggle('is-queued', number > completedStages && number <= requestedStages && number !== segmentTarget);
    });
    if (progress) {
      progress.setAttribute('aria-valuenow', String(clamp(shownProgress, 0, chapters.length)));
      const text = segmentPlaying
        ? queuedMoves
          ? `در حال پخش حرکت ${toFa(activeValue)}؛ ${toFa(queuedMoves)} حرکت دیگر در صف`
          : `در حال پخش حرکت ${toFa(activeValue)} از ${toFa(chapters.length)}`
        : completedStages
          ? `${toFa(completedStages)} حرکت از ${toFa(chapters.length)} کامل شده`
          : `آمادهٔ شروع؛ ${toFa(chapters.length)} حرکت`;
      progress.setAttribute('aria-valuetext', text);
    }
    if (chapterCard && animate) {
      chapterCard.style.animation = 'none';
      void chapterCard.offsetWidth;
      chapterCard.style.animation = '';
    }

    film.classList.toggle('is-playing', segmentPlaying);
    film.classList.toggle('is-final-stage', displayStage === chapters.length);
    if (segmentPlaying) {
      if (cueText) cueText.textContent = queuedMoves
        ? `${toFa(queuedMoves)} حرکت اسکرول دیگر در صف پخش است`
        : segmentTarget >= chapters.length && segmentDirection > 0
          ? 'بخش پایانی در حال پخش است'
          : 'در حال پخش؛ بعد از پایان، یک اسکرول دیگر';
    } else if (completedStages >= chapters.length) {
      if (cue) cue.hidden = true;
    } else if (cueText) {
      cueText.textContent = completedStages
        ? `برای حرکت ${toFa(completedStages + 1)}، یک بار اسکرول کنید`
        : 'برای آغاز روایت، اسکرول کنید';
    }
  }

  function markCompleted() {
    completed = true;
    root.classList.add('implant-film-seen');
  }

  function setFinalFrame() {
    if (video.readyState < 1 || !getDuration()) return;
    video.pause();
    reverseVideo.pause();
    const end = lastFrameTime();
    if (Math.abs(video.currentTime - end) > .06) {
      try { video.currentTime = end; } catch { /* Native controls remain available in the fallback. */ }
    }
  }

  function setCapability() {
    if (!canPin()) {
      if (entering) cancelEntry();
      if (active) releaseWithoutCompletion(lockTop, true);
      film.classList.remove('is-enhanced');
      video.controls = true;
      if (reducedMotion.matches) {
        setHelp('به‌دلیل تنظیم کاهش حرکت، ویدیو با کنترل‌های معمول پخش می‌شود.');
        setStatus('حالت کاهش حرکت فعال است؛ کنترل‌های ویدیو در دسترس‌اند.');
      } else if (!tallEnough()) {
        setHelp('در صفحهٔ کوتاه، قفل اسکرول خاموش است؛ از کنترل‌های ویدیو استفاده کنید.');
        setStatus('صفحه برای روایت تمام‌صفحه کوتاه است؛ کنترل‌های ویدیو فعال‌اند.');
      }
      return;
    }
    film.classList.add('is-enhanced');
    video.controls = false;
    if (completed) {
      film.classList.add('is-complete');
      setHelp('برای اجرای دوباره، صفحه را رفرش کنید.');
      setStatus('روایت کامل شد؛ برای اجرای دوباره، صفحه را رفرش کنید.');
      setFinalFrame();
    } else if (!active) {
      setHelp('هر بار اسکرول، یک بخش را پیش می‌برد؛ سه حرکت تا پایان.');
      setStatus('آمادهٔ شروع؛ سه حرکت اسکرول.');
    }
  }

  function resetFilm({ replay = false } = {}) {
    segmentToken += 1;
    if (monitorRaf) cancelAnimationFrame(monitorRaf);
    monitorRaf = 0;
    segmentPlaying = false;
    segmentTarget = 0;
    segmentDirection = 1;
    completedStages = 0;
    requestedStages = 0;
    video.pause();
    reverseVideo.pause();
    video.playbackRate = 1;
    reverseVideo.playbackRate = 1;
    film.classList.remove('is-reversing', 'is-playing');
    if (video.readyState >= 1) {
      try { video.currentTime = 0; } catch { /* Wait for metadata. */ }
    }
    if (reverseVideo.readyState >= 1) {
      try { reverseVideo.currentTime = 0; } catch { /* Reverse asset is optional in fallback mode. */ }
    }
    film.classList.toggle('is-replaying', replay);
    film.classList.remove('is-complete');
    if (cue) cue.hidden = false;
    refreshUI({ animate: false });
  }

  function scrollToImmediately(top) {
    const previous = root.style.scrollBehavior;
    root.style.scrollBehavior = 'auto';
    window.scrollTo(0, Math.max(0, Math.round(top)));
    root.style.scrollBehavior = previous;
  }

  function cancelEntry() {
    if (!entering) return;
    entering = false;
    entryToken += 1;
    if (entryRaf) cancelAnimationFrame(entryRaf);
    entryRaf = 0;
    // Stop an in-flight smooth scroll if the video or viewport can no longer support pinning.
    scrollToImmediately(window.scrollY);
  }

  function activateLock({ replay = false, token } = {}) {
    if (!entering || token !== entryToken) return false;
    if (!canPin()) { cancelEntry(); return false; }
    entering = false;
    entryRaf = 0;
    lockTop = Math.max(0, documentTop());
    lastScrollY = window.scrollY;
    active = true;
    replaying = Boolean(replay);
    film.classList.add('is-active');
    root.style.setProperty('--implant-lock-top', `${-Math.round(lockTop)}px`);
    root.classList.add('implant-scroll-locked');
    resetFilm({ replay });
    setHelp('روایت آماده است؛ هر بار اسکرول یک حرکت را اجرا می‌کند. پس از سه حرکت، اسکرول دیگری به خدمات می‌برد.');
    setStatus('به روایت رسیدید؛ برای اجرای حرکت نخست یک بار اسکرول کنید.');
    if (heading && typeof heading.focus === 'function') heading.focus({ preventScroll: true });
    return true;
  }

  function enterLock({ replay = false } = {}) {
    if (active || entering || !canPin() || (completed && !replay)) return false;
    if (!replay && performance.now() < reenterBlockedUntil) return false;
    // Arriving with a swipe must not also count as the first move.
    if (touchInProgress) skipTouchAdvance = true;

    const targetY = Math.max(0, documentTop());
    const token = ++entryToken;
    entering = true;
    const distance = Math.abs(window.scrollY - targetY);
    if (distance <= 1) return activateLock({ replay, token });

    // Align the story with the viewport first. Only after the soft scroll settles do we pin it,
    // so changing the stage to fixed positioning never produces a visible jump.
    const startedAt = performance.now();
    let previousY = window.scrollY;
    let stableFrames = 0;
    window.scrollTo({ left: 0, top: targetY, behavior: 'smooth' });

    const waitForAlignment = () => {
      if (!entering || token !== entryToken) return;
      if (!canPin()) { cancelEntry(); return; }
      const currentY = window.scrollY;
      const aligned = Math.abs(currentY - targetY) <= 1;
      stableFrames = aligned && Math.abs(currentY - previousY) <= .5 ? stableFrames + 1 : 0;
      if (stableFrames >= 2) {
        activateLock({ replay, token });
        return;
      }
      if (performance.now() - startedAt >= 5500) {
        scrollToImmediately(targetY);
        entryRaf = requestAnimationFrame(() => activateLock({ replay, token }));
        return;
      }
      previousY = currentY;
      entryRaf = requestAnimationFrame(waitForAlignment);
    };
    entryRaf = requestAnimationFrame(waitForAlignment);
    return true;
  }

  function unlockTo(destination, behavior = 'auto') {
    active = false;
    replaying = false;
    segmentPlaying = false;
    segmentToken += 1;
    if (monitorRaf) cancelAnimationFrame(monitorRaf);
    monitorRaf = 0;
    film.classList.remove('is-active', 'is-replaying', 'is-reversing', 'is-playing');
    root.classList.remove('implant-scroll-locked');
    root.style.removeProperty('--implant-lock-top');
    video.pause();
    reverseVideo.pause();
    const oldBehavior = root.style.scrollBehavior;
    root.style.scrollBehavior = 'auto';
    const top = Math.max(0, Math.round(destination));
    if (behavior === 'smooth' && !reducedMotion.matches) {
      window.scrollTo({ left: 0, top, behavior: 'smooth' });
    } else {
      window.scrollTo(0, top);
    }
    root.style.scrollBehavior = oldBehavior;
    lastScrollY = window.scrollY;
  }

  function releaseWithoutCompletion(destination, preserveProgress) {
    if (!active) return;
    unlockTo(destination);
    requestedStages = completedStages;
    segmentTarget = 0;
    segmentPlaying = false;
    if (!preserveProgress && !completed) resetFilm();
    video.controls = true;
  }

  function completePlayback() {
    if (!active || (completed && !replaying)) return;
    video.pause();
    reverseVideo.pause();
    film.classList.remove('is-reversing', 'is-replaying');
    completedStages = chapters.length;
    requestedStages = chapters.length;
    segmentPlaying = false;
    segmentTarget = 0;
    replaying = false;
    film.classList.add('is-complete');
    if (cue) cue.hidden = true;
    refreshUI();
    markCompleted();
    const navigationId = pendingNavigation;
    pendingNavigation = null;
    if (!navigationId) {
      setHelp('برای اجرای دوباره، صفحه را رفرش کنید.');
      setStatus('روایت کامل شد؛ برای ادامه اسکرول کنید و برای اجرای دوباره، صفحه را رفرش کنید.');
      return;
    }

    setHelp('سه حرکت کامل شد؛ صفحه با اسکرول نرم به بخش درخواستی می‌رود.');
    setStatus('پایان روایت؛ حرکت نرم به بخش درخواستی آغاز شد.');
    const nextY = lockTop + film.offsetHeight - servicesEntryOffset();
    unlockTo(nextY, 'smooth');
    const target = document.getElementById(navigationId);
    if (target) {
      history.pushState(null, '', `#${encodeURIComponent(navigationId)}`);
      requestAnimationFrame(() => {
        const oldBehavior = root.style.scrollBehavior;
        root.style.scrollBehavior = 'auto';
        const scrollBehavior = reducedMotion.matches ? 'auto' : 'smooth';
        if (target.id === 'services') {
          const destination = target.getBoundingClientRect().top + window.scrollY - servicesEntryOffset();
          window.scrollTo({ left: 0, top: Math.max(0, Math.round(destination)), behavior: scrollBehavior });
        } else target.scrollIntoView({ behavior: scrollBehavior, block: 'start' });
        root.style.scrollBehavior = oldBehavior;
      });
    }
  }

  function settleBoundary(token, stage) {
    if (!active || token !== segmentToken) return;
    const end = chapterEnd(stage);
    video.pause();
    video.playbackRate = 1;
    const commit = () => {
      if (!active || token !== segmentToken) return;
      video.pause();
      completedStages = stage;
      segmentPlaying = false;
      segmentTarget = 0;
      segmentDirection = 1;
      refreshUI({ animate: false });
      if (completedStages >= chapters.length && requestedStages >= completedStages) {
        let finished = false;
        const finish = () => {
          if (finished || !active || token !== segmentToken || completedStages < chapters.length || requestedStages < completedStages) return;
          finished = true;
          completePlayback();
        };
        requestAnimationFrame(() => requestAnimationFrame(finish));
        window.setTimeout(finish, 360);
      } else {
        processQueue();
      }
    };

    if (video.readyState >= 1 && Math.abs(video.currentTime - end) > .055 && !video.seeking) {
      video.addEventListener('seeked', commit, { once: true });
      try { video.currentTime = end; } catch { commit(); }
    } else if (video.seeking) {
      video.addEventListener('seeked', commit, { once: true });
    } else commit();
  }

  // Ease the playback rate in and out so each move glides instead of snapping on and off.
  const smooth = n => n * n * (3 - 2 * n);
  function easedRate(elapsed, remaining) {
    const rampIn = smooth(clamp(elapsed / RAMP_IN));
    const rampOut = smooth(clamp(remaining / RAMP_OUT));
    return RATE_MIN + (PLAY_SPEED - RATE_MIN) * Math.min(rampIn, rampOut);
  }
  function setRate(media, rate) {
    if (Math.abs(media.playbackRate - rate) > .015) {
      try { media.playbackRate = rate; } catch { /* Some browsers clamp very low rates. */ }
    }
  }

  function monitorForward(token, stage) {
    if (!active || !segmentPlaying || token !== segmentToken || segmentDirection !== 1) return;
    const start = stage === 1 ? 0 : chapterEnd(stage - 1);
    const end = chapterEnd(stage);
    if (video.ended || video.currentTime >= end - .035) {
      settleBoundary(token, stage);
      return;
    }
    setRate(video, easedRate(video.currentTime - start, end - video.currentTime));
    monitorRaf = requestAnimationFrame(() => monitorForward(token, stage));
  }

  function fallbackScrub(token, stage, startTime, endTime) {
    if (!active || token !== segmentToken) return;
    video.pause();
    segmentDirection = 1;
    const durationMs = Math.max(520, Math.min(1200, Math.abs(endTime - startTime) * 360));
    const start = performance.now();
    let lastSet = -Infinity;
    function tick(now) {
      if (!active || token !== segmentToken) return;
      const raw = clamp((now - start) / durationMs);
      const eased = 1 - Math.pow(1 - raw, 3);
      const desired = startTime + (endTime - startTime) * eased;
      if (!video.seeking && now - lastSet >= 40 && Math.abs(video.currentTime - desired) > .045) {
        try { video.currentTime = desired; lastSet = now; } catch { /* Continue to the next frame. */ }
      }
      if (raw >= 1 && !video.seeking && Math.abs(video.currentTime - endTime) <= .08) {
        settleBoundary(token, stage);
      } else monitorRaf = requestAnimationFrame(tick);
    }
    monitorRaf = requestAnimationFrame(tick);
  }

  function startForward(stage) {
    const token = ++segmentToken;
    const startTime = stage === 1 ? 0 : chapterEnd(stage - 1);
    const endTime = chapterEnd(stage);
    segmentTarget = stage;
    segmentDirection = 1;
    segmentPlaying = true;
    refreshUI({ animate: true });
    setStatus(`در حال پخش بخش ${toFa(stage)} از سه: ${chapters[stage - 1].title}`);
    if (cueText) cueText.textContent = stage === chapters.length
      ? 'بخش پایانی در حال پخش است'
      : 'در حال پخش؛ بعد از پایان، یک اسکرول دیگر';

    const play = () => {
      if (!active || token !== segmentToken) return;
      if (Math.abs(video.currentTime - startTime) > .07 && video.readyState >= 1) {
        const onSeeked = () => {
          if (active && token === segmentToken) play();
        };
        video.addEventListener('seeked', onSeeked, { once: true });
        try { video.currentTime = startTime; } catch { fallbackScrub(token, stage, video.currentTime, endTime); }
        return;
      }
      video.playbackRate = RATE_MIN;
      const promise = video.play();
      if (promise && typeof promise.then === 'function') {
        promise.then(() => monitorForward(token, stage)).catch(() => fallbackScrub(token, stage, video.currentTime, endTime));
      } else monitorForward(token, stage);
    };
    play();
  }

  function finishReverse(token, targetStage, endTime) {
    if (!active || token !== segmentToken || !segmentPlaying || segmentDirection !== -1) return;
    reverseVideo.pause();
    reverseVideo.playbackRate = 1;
    let committed = false;
    const commit = () => {
      if (committed || !active || token !== segmentToken || !segmentPlaying || segmentDirection !== -1) return;
      committed = true;
      film.classList.remove('is-reversing');
      video.pause();
      completedStages = targetStage;
      segmentPlaying = false;
      segmentTarget = 0;
      segmentDirection = 1;
      refreshUI({ animate: false });
      if (requestedStages !== completedStages) processQueue();
      else setStatus(targetStage ? `بازگشت به بخش ${toFa(targetStage)} از سه` : 'بازگشت به آغاز روایت');
    };
    const seekForwardFrame = () => {
      if (video.readyState >= 1 && Math.abs(video.currentTime - endTime) > .055 && !video.seeking) {
        let settled = false;
        const settle = () => {
          if (settled) return;
          settled = true;
          commit();
        };
        video.addEventListener('seeked', settle, { once: true });
        window.setTimeout(settle, 900);
        try { video.currentTime = endTime; } catch { settle(); }
      } else if (video.seeking) {
        video.addEventListener('seeked', commit, { once: true });
        window.setTimeout(commit, 900);
      } else commit();
    };
    seekForwardFrame();
  }

  function monitorReverse(token, targetStage, reverseEndTime, endTime, reverseStartTime = 0) {
    if (!active || !segmentPlaying || token !== segmentToken || segmentDirection !== -1) return;
    if (reverseVideo.error || reverseVideo.ended || reverseVideo.currentTime >= reverseEndTime - .035) {
      finishReverse(token, targetStage, endTime);
      return;
    }
    setRate(reverseVideo, easedRate(reverseVideo.currentTime - reverseStartTime, reverseEndTime - reverseVideo.currentTime));
    monitorRaf = requestAnimationFrame(() => monitorReverse(token, targetStage, reverseEndTime, endTime, reverseStartTime));
  }

  function startReverse(targetStage) {
    if (targetStage < 0 || !active) return;
    const token = ++segmentToken;
    const endTime = targetStage === 0 ? 0 : chapterEnd(targetStage);
    const reverseStartTime = reverseTimeFor(video.currentTime);
    const reverseEndTime = reverseTimeFor(endTime);
    segmentTarget = targetStage || 1;
    segmentDirection = -1;
    segmentPlaying = true;
    refreshUI({ animate: true });
    setStatus(targetStage ? `در حال پخش معکوس تا بخش ${toFa(targetStage)} از سه` : 'در حال بازگشت معکوس به آغاز روایت');
    video.pause();
    reverseVideo.pause();
    film.classList.remove('is-reversing');

    const fallback = () => {
      if (!active || token !== segmentToken || !segmentPlaying || segmentDirection !== -1) return;
      reverseVideo.pause();
      film.classList.remove('is-reversing');
      finishReverse(token, targetStage, endTime);
    };
    if (reverseVideo.error || !reverseVideo.canPlayType('video/mp4')) {
      fallback();
      return;
    }

    let started = false;
    let startupTimer = 0;
    const playReverse = () => {
      if (started || !active || token !== segmentToken || !segmentPlaying) return;
      started = true;
      if (startupTimer) window.clearTimeout(startupTimer);
      film.classList.add('is-reversing');
      reverseVideo.playbackRate = RATE_MIN;
      const promise = reverseVideo.play();
      if (promise && typeof promise.then === 'function') {
        promise.then(() => monitorReverse(token, targetStage, reverseEndTime, endTime, reverseStartTime)).catch(fallback);
      } else monitorReverse(token, targetStage, reverseEndTime, endTime, reverseStartTime);
    };
    const seekReverseFrame = () => {
      if (!active || token !== segmentToken || !segmentPlaying) return;
      if (reverseVideo.error || !Number.isFinite(reverseVideo.duration) || reverseVideo.duration <= 0) {
        fallback();
        return;
      }
      if (Math.abs(reverseVideo.currentTime - reverseStartTime) <= .04) {
        playReverse();
        return;
      }
      reverseVideo.addEventListener('seeked', playReverse, { once: true });
      try { reverseVideo.currentTime = reverseStartTime; }
      catch { fallback(); }
    };
    if (reverseVideo.readyState >= 1 && Number.isFinite(reverseVideo.duration)) {
      seekReverseFrame();
    } else {
      reverseVideo.addEventListener('loadedmetadata', seekReverseFrame, { once: true });
      startupTimer = window.setTimeout(fallback, 1800);
    }
  }

  function processQueue() {
    if (!active || segmentPlaying) return;
    if (requestedStages > completedStages) {
      startForward(completedStages + 1);
      return;
    }
    if (requestedStages < completedStages) {
      startReverse(Math.max(requestedStages, completedStages - 1));
      return;
    }
    refreshUI();
    if (completedStages >= chapters.length) completePlayback();
    else if (completedStages) setStatus(`بخش ${toFa(completedStages)} کامل شد؛ برای ادامه یک بار اسکرول کنید.`);
  }

  // Leaving upward is allowed before the first move; everything else waits for the film to finish.
  function exitUp() {
    if (!active || segmentPlaying || completedStages > 0 || requestedStages > 0) return;
    reenterBlockedUntil = performance.now() + REENTER_COOLDOWN;
    userIntentUntil = 0;
    unlockTo(lockTop);
    setStatus('به بالای صفحه برگشتید؛ با اسکرول رو به پایین دوباره وارد روایت می‌شوید.');
  }

  // One gesture = one move. Same-direction gestures are queued while the current move finishes;
  // the final requested stage is capped at the story ends, and an opposite gesture turns the film around.
  function advanceOne(direction = 1) {
    if (!active || !direction) return;
    if (completed && completedStages >= chapters.length && !segmentPlaying) {
      if (direction > 0) {
        setStatus('حرکت نرم به خدمات آغاز شد.');
        unlockTo(lockTop + film.offsetHeight - servicesEntryOffset(), 'smooth');
        return;
      }
      replaying = true;
      film.classList.add('is-replaying');
    }
    fireSparkBurst();
    if (segmentPlaying) {
      if (direction === segmentDirection) {
        if (direction > 0) {
          requestedStages = Math.min(chapters.length, Math.max(requestedStages, segmentTarget, completedStages) + 1);
          setStatus(requestedStages > segmentTarget ? `حرکت ${toFa(requestedStages)} در صف پخش قرار گرفت.` : 'بخش پایانی در حال پخش است.');
        } else {
          requestedStages = Math.max(0, Math.min(requestedStages, segmentTarget, completedStages) - 1);
          setStatus(requestedStages < segmentTarget ? 'یک حرکت دیگر برای بازگشت در صف است.' : 'در حال بازگشت؛ حرکت بعدی نیز ثبت شد.');
        }
        refreshUI();
        return;
      }
      if (segmentDirection > 0) {
        requestedStages = completedStages;
        startReverse(completedStages);
      } else {
        if (requestedStages < segmentTarget) requestedStages = segmentTarget;
        else if (requestedStages < completedStages) requestedStages = completedStages;
        else requestedStages = Math.min(chapters.length, requestedStages + 1);
        refreshUI();
        setStatus('ادامهٔ روایت رو به جلو در صف قرار گرفت.');
      }
      return;
    }
    if (direction > 0) {
      if (completedStages >= chapters.length) return;
      requestedStages = Math.min(chapters.length, Math.max(requestedStages, completedStages) + 1);
      refreshUI();
      processQueue();
      return;
    }
    if (completedStages === 0) { exitUp(); return; }
    requestedStages = Math.max(0, Math.min(requestedStages || completedStages, completedStages) - 1);
    processQueue();
  }

  function enterAndCount() {
    return enterLock();
  }

  function markIntent() { userIntentUntil = performance.now() + 1500; }
  function wheelDirectionFrom(event) { return event.deltaY > 0 ? 1 : event.deltaY < 0 ? -1 : 0; }

  // Group low-delta trackpad inertia; a notch-sized pulse, short silence, direction change, or fresh swipe
  // begins a new gesture so rapid deliberate inputs can each enter the queue.
  function trackWheel(now, direction, magnitude, discreteImpulse = false) {
    const w = wheelState;
    let fresh = discreteImpulse || now - w.last > WHEEL_IDLE_MS || direction !== w.dir;
    w.mags.push(magnitude);
    if (w.mags.length > 3) w.mags.shift();
    const level = w.mags.reduce((sum, n) => sum + n, 0) / w.mags.length;
    if (!fresh && w.decaying && level > w.valley * 1.7 + 8) fresh = true;
    if (fresh) {
      w.mags = [magnitude];
      w.count = 0;
      w.peak = magnitude;
      w.valley = Infinity;
      w.decaying = false;
      w.total = 0;
      w.consumed = false;
    } else {
      w.peak = Math.max(w.peak, level);
      if (!w.decaying && w.count >= 5 && level < w.peak * .5) { w.decaying = true; w.valley = level; }
      if (w.decaying) w.valley = Math.min(w.valley, level);
    }
    w.count += 1;
    w.total += magnitude;
    w.dir = direction;
    w.last = now;
    return w;
  }

  function handleWheel(event) {
    if (event.ctrlKey || !event.deltaY) return;
    if (Math.abs(event.deltaX) > Math.abs(event.deltaY) * 1.5) return;
    const direction = wheelDirectionFrom(event);
    const unit = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? window.innerHeight : 1;
    const magnitude = Math.abs(event.deltaY) * unit;
    const discreteImpulse = event.deltaMode !== 0 || magnitude >= WHEEL_IMPULSE_MIN;
    const gesture = trackWheel(performance.now(), direction, magnitude, discreteImpulse);

    if (active) {
      if (event.cancelable) event.preventDefault();
      markIntent();
      if (!gesture.consumed && gesture.total >= WHEEL_MIN_TOTAL) {
        gesture.consumed = true;
        advanceOne(direction);
      }
      return;
    }
    if (entering) {
      if (event.cancelable) event.preventDefault();
      markIntent();
      return;
    }
    if (!canPin() || completed || direction < 0) return;
    markIntent();
    const topInView = film.getBoundingClientRect().top;
    if (topInView <= magnitude + 1) {
      if (event.cancelable) event.preventDefault();
      // Arriving never starts a move: the opening frame is shown first and the next gesture plays move one.
      if (enterLock()) gesture.consumed = true;
    }
  }

  function isEditable(target) {
    return Boolean(target instanceof Element && target.closest('input, textarea, select, [contenteditable="true"], [role="textbox"], video'));
  }
  function handleKeydown(event) {
    if (isEditable(event.target)) return;
    if (event.repeat) return;
    const key = event.key;
    const isForward = ['ArrowDown', 'PageDown', 'End', ' '].includes(key);
    const isBackward = ['ArrowUp', 'PageUp', 'Home'].includes(key);
    if (!isForward && !isBackward) return;
    if (key === ' ' && event.target instanceof Element && event.target.closest('button, a, [role="button"]')) return;

    if (entering) {
      event.preventDefault();
      return;
    }
    if (active) {
      event.preventDefault();
      markIntent();
      advanceOne(isForward ? 1 : -1);
      return;
    }
    if (!canPin() || completed) return;
    markIntent();
    if (key === 'End') {
      event.preventDefault();
      enterAndCount(1);
      return;
    }
    const top = documentTop();
    const bottom = top + film.offsetHeight;
    const y = window.scrollY;
    const step = ['PageDown', 'PageUp', ' '].includes(key) ? window.innerHeight : 90;
    const destination = y + (isBackward ? -step : step);
    const crossingFromAbove = y < top && destination >= top;
    const crossingFromBelow = y >= bottom && destination < bottom;
    const within = y >= top && y < bottom;
    if (crossingFromAbove || crossingFromBelow || within) {
      event.preventDefault();
      enterAndCount(isForward ? 1 : -1);
    }
  }

  function handleTouchStart(event) {
    if (!event.touches || !event.touches.length) return;
    touchInProgress = true;
    skipTouchAdvance = false;
    touchMoved = false;
    touchStartY = event.touches[0].clientY;
    touchLastY = touchStartY;
    markIntent();
  }
  function handleTouchMove(event) {
    if (!event.touches || !event.touches.length) return;
    const y = event.touches[0].clientY;
    if (touchStartY !== null && Math.abs(y - touchStartY) >= 2) touchMoved = true;
    if (active || entering) {
      if (event.cancelable) event.preventDefault();
    }
    touchLastY = y;
    markIntent();
  }
  function clearTouch() {
    touchInProgress = false;
    touchMoved = false;
    touchStartY = null;
    touchLastY = null;
    lastTouchEndAt = performance.now();
  }
  function handleTouchEnd() {
    const endY = touchLastY;
    const direction = touchStartY !== null && endY !== null ? (touchStartY - endY > 0 ? 1 : touchStartY - endY < 0 ? -1 : 0) : 0;
    if (active && !entering && !skipTouchAdvance && touchMoved && direction && Math.abs(touchStartY - endY) >= TOUCH_MIN_TRAVEL) advanceOne(direction);
    skipTouchAdvance = false;
    clearTouch();
  }
  function handleTouchCancel() { clearTouch(); }

  function handleScroll() {
    const y = window.scrollY;
    if (!active && !entering && !completed && canPin() && performance.now() <= userIntentUntil) {
      const top = documentTop();
      const bottom = top + film.offsetHeight;
      const previous = lastScrollY;
      const crossedDown = previous < top && y >= top;
      const crossedUp = previous >= bottom && y < bottom;
      const inside = y >= top && y < bottom;
      if (crossedDown || crossedUp || inside) {
        enterLock();
      }
    }
    lastScrollY = window.scrollY;
  }

  function findAnchorTarget(link) {
    const raw = link.getAttribute('href');
    if (!raw || raw === '#') return null;
    let id = raw.slice(1);
    try { id = decodeURIComponent(id); } catch { /* Use the literal fragment. */ }
    return document.getElementById(id);
  }
  function handleAnchorClick(event) {
    const link = event.target instanceof Element ? event.target.closest('a[href^="#"]') : null;
    if (!link || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    if (!canPin() && !active) return;
    const target = findAnchorTarget(link);
    if (!target) return;
    const storyTop = documentTop();
    const targetTop = target.getBoundingClientRect().top + window.scrollY;
    const targetIsStoryOrAfter = target === film || (targetTop >= storyTop && (film.compareDocumentPosition(target) & Node.DOCUMENT_POSITION_FOLLOWING));
    if (entering) {
      if (!targetIsStoryOrAfter) { cancelEntry(); return; }
      event.preventDefault();
      pendingNavigation = target === film ? null : target.id;
      return;
    }
    if (active) {
      event.preventDefault();
      pendingNavigation = target === film ? null : target.id;
      return;
    }
    if (completed || !targetIsStoryOrAfter) return;
    event.preventDefault();
    pendingNavigation = target === film ? null : target.id;
    enterLock();
  }

  function handleMetadata() {
    if (completed && !active) setFinalFrame();
  }
  function handleVideoError() {
    mediaFailed = true;
    film.classList.add('is-error');
    if (entering) cancelEntry();
    if (active) releaseWithoutCompletion(lockTop, true);
    film.classList.remove('is-enhanced');
    video.controls = true;
    setHelp('ویدیو بارگذاری نشد؛ کنترل‌های معمول پخش در دسترس‌اند و اسکرول قفل نمی‌شود.');
    setStatus('بارگذاری ویدیو ناموفق بود؛ قفل روایت خاموش شد.');
  }
  function handleScrollbarPointer(event) {
    if (event.pointerType === 'mouse' && (event.clientX >= window.innerWidth - 18 || event.clientY >= window.innerHeight - 18)) markIntent();
  }

  function initialise() {
    if (initDone) return;
    initDone = true;
    if (video.error) { handleVideoError(); return; }
    setCapability();
    lastScrollY = window.scrollY;
    requestAnimationFrame(() => {
      if (!canPin() || completed) return;
      let hashTarget = null;
      if (location.hash.length > 1) {
        try { hashTarget = document.getElementById(decodeURIComponent(location.hash.slice(1))); } catch { hashTarget = null; }
      }
      if (hashTarget) {
        const top = documentTop();
        const targetTop = hashTarget.getBoundingClientRect().top + window.scrollY;
        if (hashTarget === film || (targetTop >= top && (film.compareDocumentPosition(hashTarget) & Node.DOCUMENT_POSITION_FOLLOWING))) {
          pendingNavigation = hashTarget === film ? null : hashTarget.id;
          enterLock();
          return;
        }
      }
      const top = documentTop();
      if (window.scrollY >= top && window.scrollY < top + film.offsetHeight) enterLock();
    });
  }

  video.addEventListener('loadedmetadata', handleMetadata);
  video.addEventListener('error', handleVideoError);
  window.addEventListener('wheel', handleWheel, { passive: false, capture: true });
  window.addEventListener('keydown', handleKeydown, { capture: true });
  window.addEventListener('touchstart', handleTouchStart, { passive: true, capture: true });
  window.addEventListener('touchmove', handleTouchMove, { passive: false, capture: true });
  window.addEventListener('touchend', handleTouchEnd, { passive: true, capture: true });
  window.addEventListener('touchcancel', handleTouchCancel, { passive: true, capture: true });
  window.addEventListener('scroll', handleScroll, { passive: true });
  window.addEventListener('resize', setCapability, { passive: true });
  window.addEventListener('pointerdown', handleScrollbarPointer, { passive: true, capture: true });
  document.addEventListener('click', handleAnchorClick, true);
  if (typeof reducedMotion.addEventListener === 'function') reducedMotion.addEventListener('change', setCapability);
  else if (typeof reducedMotion.addListener === 'function') reducedMotion.addListener(setCapability);
  initialise();
}
