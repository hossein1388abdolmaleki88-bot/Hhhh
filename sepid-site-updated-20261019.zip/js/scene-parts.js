import * as THREE from '../vendor/three.module.js';

export class ToothModel extends THREE.Group {
  static async create(config, signal) {
    const response = await fetch(new URL('../assets/tooth.bin', import.meta.url), { signal });
    if (!response.ok) throw new Error(`Tooth asset HTTP ${response.status}`);
    const bytes = await response.arrayBuffer();
    const header = new DataView(bytes);
    if (header.getUint32(0, true) !== 0x48544f54 || header.getUint32(4, true) !== 1) {
      throw new Error('Unsupported tooth geometry');
    }
    const vertexCount = header.getUint32(8, true);
    const indexCount = header.getUint32(12, true);
    if (bytes.byteLength !== 16 + vertexCount * 12 + indexCount * 4) throw new Error('Invalid mesh length');
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(bytes, 16, vertexCount * 3), 3));
    geometry.setIndex(new THREE.BufferAttribute(new Uint32Array(bytes, 16 + vertexCount * 12, indexCount), 1));
    const normalResponse = await fetch(new URL('../assets/tooth-normals.bin', import.meta.url), { signal });
    if (!normalResponse.ok) throw new Error('Could not load enamel normals');
    const normalBytes = await normalResponse.arrayBuffer();
    if (normalBytes.byteLength !== vertexCount * 12) throw new Error('Invalid normal data');
    geometry.setAttribute('normal', new THREE.BufferAttribute(new Float32Array(normalBytes), 3));
    geometry.computeBoundingSphere();
    const model = new ToothModel();
    const material = new THREE.MeshPhysicalMaterial({
      color: config.enamelColor,
      metalness: 0,
      roughness: config.toothRoughness,
      clearcoat: config.highlightIntensity,
      clearcoatRoughness: 0.04,
      ior: 1.46,
      reflectivity: 0.5,
      transmission: config.translucency,
      thickness: 0.25,
      attenuationColor: new THREE.Color('#f8fbff'),
      attenuationDistance: 2.6,
      envMapIntensity: 1.15,
      specularIntensity: 1.0
    });
    // Keep the large white softbox highlights without flattening the enamel
    // with excessive diffuse environment fill. Direct light still defines volume.
    material.onBeforeCompile = shader => {
      shader.fragmentShader = shader.fragmentShader.replace('#include <lights_fragment_maps>',
        THREE.ShaderChunk.lights_fragment_maps.replace(
          'iblIrradiance += getIBLIrradiance( geometryNormal );',
          'iblIrradiance += getIBLIrradiance( geometryNormal ) * 0.52;'
        ));
    };
    model.mesh = new THREE.Mesh(geometry, material);
    model.mesh.castShadow = true;
    model.mesh.receiveShadow = false;
    model.add(model.mesh);
    model.position.fromArray(config.toothPosition);
    model.rotation.fromArray([...config.toothRotation, 'XYZ']);
    model.scale.setScalar(config.toothScale);
    return model;
  }

  update(time, config, still) {
    // No perpetual spin: a sub-pixel-scale vertical float only.
    this.position.y = config.toothPosition[1] + (still ? 0 : Math.sin(time * 0.52) * config.floatAmplitude);
  }
}

export class Platform extends THREE.Group {
  static create(config, mobile = false) {
    return new Platform(config, mobile);
  }

  constructor(config, mobile = false) {
    super();
    const r = config.platformRadius;
    const h = config.platformHeight;
    const bevel = Math.min(.06, h * .23);
    const profile = [new THREE.Vector2(0, -h), new THREE.Vector2(r - bevel, -h)];
    for (let i = 0; i <= 8; i++) {
      const a = -Math.PI / 2 + i / 8 * Math.PI / 2;
      profile.push(new THREE.Vector2(r - bevel + Math.cos(a) * bevel, -h + bevel + Math.sin(a) * bevel));
    }
    profile.push(new THREE.Vector2(r, -bevel));
    for (let i = 0; i <= 8; i++) {
      const a = i / 8 * Math.PI / 2;
      profile.push(new THREE.Vector2(r - bevel + Math.cos(a) * bevel, -bevel + Math.sin(a) * bevel));
    }
    profile.push(new THREE.Vector2(0, 0));

    const geometry = new THREE.LatheGeometry(profile, mobile ? 128 : 192);
    geometry.computeVertexNormals();
    this.edgeMaterial = new THREE.MeshPhysicalMaterial({
      color: config.platformColor,
      metalness: .015,
      roughness: .16,
      clearcoat: .96,
      clearcoatRoughness: .045,
      ior: 1.42,
      reflectivity: .58,
      transmission: .18,
      thickness: .32,
      attenuationColor: '#B8DDF2',
      attenuationDistance: 1.8,
      envMapIntensity: 1.12,
      specularIntensity: .85
    });
    this.body = new THREE.Mesh(geometry, this.edgeMaterial);
    this.body.receiveShadow = true;
    this.body.castShadow = true;
    this.add(this.body);

    // A pearl-white, softly polished top stays less glossy than the crystal edge.
    const topGeometry = new THREE.CircleGeometry(r - bevel - .035, mobile ? 96 : 192);
    this.topMaterial = new THREE.MeshPhysicalMaterial({
      color: '#F9FCFF',
      metalness: 0,
      roughness: .27,
      clearcoat: .62,
      clearcoatRoughness: .11,
      ior: 1.36,
      reflectivity: .48,
      transmission: .04,
      thickness: .1,
      attenuationColor: '#F9FCFF',
      attenuationDistance: 2.4,
      envMapIntensity: .92,
      specularIntensity: .72
    });
    this.top = new THREE.Mesh(topGeometry, this.topMaterial);
    this.top.rotation.x = -Math.PI / 2;
    this.top.position.y = .003;
    this.top.receiveShadow = true;
    this.add(this.top);

    // One slim icy highlight gives the upper lip a polished, glass-like edge.
    this.lipMaterial = new THREE.MeshPhysicalMaterial({
      color: '#E8F6FD',
      metalness: .025,
      roughness: .13,
      clearcoat: 1,
      clearcoatRoughness: .035,
      ior: 1.4,
      transmission: .13,
      thickness: .16,
      attenuationColor: '#D8EFFB',
      attenuationDistance: 1.6,
      envMapIntensity: 1.15,
      specularIntensity: .9,
      emissive: '#B8DDF2',
      emissiveIntensity: .018
    });
    this.lip = new THREE.Mesh(
      new THREE.TorusGeometry(r - bevel - .012, .013, 10, mobile ? 128 : 192),
      this.lipMaterial
    );
    this.lip.rotation.x = -Math.PI / 2;
    this.lip.position.y = -.006;
    this.add(this.lip);

    // A low-opacity radial wash creates a restrained ice-blue halo below the plinth.
    const aura = new THREE.Mesh(
      new THREE.PlaneGeometry(r * 3.1, r * 3.1),
      new THREE.ShaderMaterial({
        uniforms: { uColor: { value: new THREE.Color('#B8DDF2') } },
        vertexShader: `
          varying vec2 vUv;
          void main() {
            vUv = uv;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.);
          }
        `,
        fragmentShader: `
          uniform vec3 uColor;
          varying vec2 vUv;
          void main() {
            float radius = length((vUv - vec2(.5)) * 2.);
            float falloff = (radius - .66) / .18;
            float band = exp(-falloff * falloff);
            float fade = 1. - smoothstep(.84, 1., radius);
            float alpha = band * fade * .12;
            gl_FragColor = vec4(uColor, alpha);
            #include <colorspace_fragment>
          }
        `,
        transparent: true,
        depthTest: true,
        depthWrite: false,
        side: THREE.DoubleSide,
        toneMapped: false
      })
    );
    aura.rotation.x = -Math.PI / 2;
    aura.position.y = -h - .004;
    aura.renderOrder = 1;
    this.aura = aura;
    this.add(aura);

    this.position.y = config.platformTop;
    this.scale.setScalar(config.platformScale);

    // Keep the real, soft contact shadow on the shared transparent background.
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(12, 12),
      new THREE.ShadowMaterial({ color: '#607A91', opacity: .22, depthWrite: false })
    );
    ground.material.onBeforeCompile = shader => {
      shader.vertexShader = 'varying vec2 vGround;\n' + shader.vertexShader;
      shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\nvGround = position.xy;');
      shader.fragmentShader = 'varying vec2 vGround;\n' + shader.fragmentShader;
      shader.fragmentShader = shader.fragmentShader.replace('#include <tonemapping_fragment>', 'gl_FragColor.a *= 1.0 - smoothstep(2.1, 3.0, length(vGround));\n#include <tonemapping_fragment>');
    };
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -h - .012;
    ground.receiveShadow = true;
    ground.renderOrder = -1;
    this.ground = ground;
    this.add(ground);

    this.setMobile(mobile);
  }

  setMobile(mobile) {
    // Keep physical refraction on desktop; clearcoat carries the crystal read on phones without a transmission pass.
    const edgeTransmission = mobile ? 0 : .18;
    const lipTransmission = mobile ? 0 : .13;
    const topTransmission = mobile ? 0 : .04;
    if (this.edgeMaterial.transmission !== edgeTransmission) {
      this.edgeMaterial.transmission = edgeTransmission;
      this.edgeMaterial.needsUpdate = true;
    }
    if (this.lipMaterial.transmission !== lipTransmission) {
      this.lipMaterial.transmission = lipTransmission;
      this.lipMaterial.needsUpdate = true;
    }
    if (this.topMaterial.transmission !== topTransmission) {
      this.topMaterial.transmission = topTransmission;
      this.topMaterial.needsUpdate = true;
    }
  }
}

export class CrystalHalo extends THREE.Group {
  constructor(config, mobile = false) {
    super();
    const radius = 1.78;
    const tube = .018;
    const geometry = new THREE.TorusGeometry(radius, tube, mobile ? 8 : 12, mobile ? 160 : 256);
    const uv = geometry.getAttribute('uv');
    const vertexColors = new Float32Array(uv.count * 3);
    const ice = new THREE.Color('#D8EFFB');
    const white = new THREE.Color('#F9FCFF');
    const gold = new THREE.Color('#D6B15E');
    const circularDistance = (a, b) => {
      const distance = Math.abs(a - b);
      return Math.min(distance, 1 - distance);
    };
    for (let i = 0; i < uv.count; i++) {
      const u = uv.getX(i);
      const whiteGlint = Math.max(
        Math.exp(-Math.pow(circularDistance(u, .04) / .065, 2)),
        Math.exp(-Math.pow(circularDistance(u, .53) / .09, 2)) * .52
      );
      const goldReflection = Math.min(.11,
        .10 * Math.exp(-Math.pow(circularDistance(u, .17) / .035, 2)) +
        .08 * Math.exp(-Math.pow(circularDistance(u, .68) / .03, 2))
      );
      const color = ice.clone().lerp(white, .24 + whiteGlint * .46).lerp(gold, goldReflection);
      vertexColors[i * 3] = color.r;
      vertexColors[i * 3 + 1] = color.g;
      vertexColors[i * 3 + 2] = color.b;
    }
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(vertexColors, 3));

    this.material = new THREE.MeshPhysicalMaterial({
      color: '#FFFFFF',
      vertexColors: true,
      metalness: .01,
      roughness: .14,
      clearcoat: .96,
      clearcoatRoughness: .04,
      ior: 1.37,
      reflectivity: .62,
      transmission: .28,
      thickness: .2,
      attenuationColor: '#D8EFFB',
      attenuationDistance: 2.6,
      envMapIntensity: 1.18,
      specularIntensity: .88,
      emissive: '#B8DDF2',
      emissiveIntensity: .025,
      depthTest: true,
      depthWrite: false
    });
    this.ring = new THREE.Mesh(geometry, this.material);
    this.ring.rotation.set(.08, -.1, 0);
    this.ring.renderOrder = -1;
    this.ring.castShadow = false;
    this.ring.receiveShadow = false;
    this.add(this.ring);
    this.position.set(0, config.toothPosition[1], -.9);
    this.setMobile(mobile);
  }

  update(time, still) {
    // The softly tinted highlight travels almost imperceptibly around the glass.
    if (!still) this.ring.rotation.z = time * .035;
  }

  setMobile(mobile) {
    const transmission = mobile ? 0 : .28;
    if (this.material.transmission !== transmission) {
      this.material.transmission = transmission;
      this.material.needsUpdate = true;
    }
  }
}

export class Lighting {
  constructor(scene, renderer, config) {
    this.resources = [];
    const key = new THREE.DirectionalLight('#ffffff', config.keyLightIntensity);
    key.position.set(-5.5, 3.8, 4.2);
    key.castShadow = true;
    key.shadow.mapSize.set(config.shadowMapSize, config.shadowMapSize);
    Object.assign(key.shadow.camera, { left: -3.5, right: 3.5, top: 3.5, bottom: -3.5, near: .5, far: 18 });
    key.shadow.normalBias = .025;
    key.shadow.bias = -.00015;
    key.shadow.intensity = .58;
    key.shadow.radius = 9;
    key.shadow.blurSamples = 12;
    scene.add(key);
    this.key = key;
    const fill = new THREE.DirectionalLight('#ebf3ff', config.fillLightIntensity);
    fill.position.set(4, 2, 3);
    scene.add(fill);
    // Broad frontal bounce provides a subtle neutral blue-white reflection under the crown.
    const bounce = new THREE.DirectionalLight('#eef4ff', .08);
    bounce.position.set(0, -1.8, 6);
    scene.add(bounce);
    scene.add(new THREE.HemisphereLight('#f4f8ff', '#778395', config.ambientIntensity));

    // A local, procedurally constructed studio environment: broad softboxes.
    const studio = new THREE.Scene();
    studio.background = new THREE.Color('#353c48');
    const card = (position, scale, intensity) => {
      const material = new THREE.MeshBasicMaterial({ color: new THREE.Color().setScalar(intensity), side: THREE.DoubleSide });
      const geometry = new THREE.PlaneGeometry(...scale);
      const plane = new THREE.Mesh(geometry, material);
      plane.position.set(...position);
      plane.lookAt(0, 0, 0);
      studio.add(plane);
      this.resources.push(material, geometry);
    };
    card([-5, 2.8, 7], [4.0, 5.2], 18.0);
    card([4.5, 1.2, 5], [1.5, 4.6], 7.0);
    card([-1, 6, 3], [7, 1.8], 9.0);
    const generator = new THREE.PMREMGenerator(renderer);
    this.environment = generator.fromScene(studio, 0, .1, 30);
    scene.environment = this.environment.texture;
    generator.dispose();
    this.resources.forEach(resource => resource.dispose());
    this.resources = [];
  }

  dispose() {
    this.environment.dispose();
    this.key.shadow.dispose();
  }
}

export class Camera extends THREE.PerspectiveCamera {
  constructor(config) {
    super(config.cameraFov, 1, .1, 50);
    this.config = config;
    this.target = new THREE.Vector3(...config.cameraTarget);
    this.baseDistance = config.cameraDistance;
    this.pointer = new THREE.Vector2();
    this.goal = new THREE.Vector2();
    this.position.set(0, config.cameraHeight, this.baseDistance);
    this.lookAt(this.target);
  }

  resize(width, height) {
    this.aspect = width / Math.max(1, height);
    // Fit both the pedestal and the full orbital envelope, including on phones.
    const halfAngle = Math.tan(THREE.MathUtils.degToRad(this.fov * .5));
    const horizontalFit = 2.78 / (halfAngle * this.aspect);
    this.baseDistance = Math.max(this.config.cameraDistance, horizontalFit);
    this.updateProjectionMatrix();
  }

  update(dt, still) {
    if (still) this.goal.set(0, 0);
    this.pointer.lerp(this.goal, 1-Math.exp(-dt*4));
    const strength = this.config.interactionStrength;
    this.position.set(this.pointer.x * strength, this.config.cameraHeight + this.pointer.y * strength, this.baseDistance);
    this.lookAt(this.target);
  }
}

export function createBackdrop(config) {
  const background = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), new THREE.ShaderMaterial({
    uniforms: { uColor: { value: new THREE.Color(config.backgroundColor) } },
    vertexShader: `varying vec2 vUv; void main(){vUv=uv;gl_Position=vec4(position.xy,.9999,1.);}`,
    fragmentShader: `
      uniform vec3 uColor;
      varying vec2 vUv;
      void main(){
        float center=exp(-length((vUv-vec2(.28,.70))*vec2(1.6,1.2))*1.2);
        vec3 color=uColor*mix(.72,1.18,center);
        gl_FragColor=vec4(color,1.);
        #include <colorspace_fragment>
      }`,
    depthWrite: false, toneMapped: false
  }));
  background.frustumCulled=false;
  background.renderOrder=-10;
  return background;
}
